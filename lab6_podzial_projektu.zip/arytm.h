#ifndef ARYTM_H
#define ARYTM_H

#include <iostream>

constexpr int piatka = 5;

int dodaj(int a, int b);
void wyswietl(int a);

#endif//ARYTM_H