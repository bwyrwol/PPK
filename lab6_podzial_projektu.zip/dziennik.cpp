﻿#include <iostream>
#include "arytm.h"


int main()
{
    std::cout << dodaj(10, 20) << std::endl;
    wyswietl(piatka);
}

