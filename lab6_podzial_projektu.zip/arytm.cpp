#include "arytm.h"

int dodaj(int a, int b)
{
    return (a + b);
}

void wyswietl(int a)
{
    std::cout << "zmienna a: " << a << std::endl;
}